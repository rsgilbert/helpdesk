export function Tickets() {

    return (
        <div>
            <h1>Tickets</h1>

            
        </div>
    )
}